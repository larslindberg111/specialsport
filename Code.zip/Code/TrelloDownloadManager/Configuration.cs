namespace TrelloDownloadManager
{
    public class Configuration
    {
        public string? InputFolder { get; set; }
        public string? OutputFolder { get; set; }
        public BoardSettings? BoardSettings { get; set; }
        public CardSettings? CardSettings { get; set; }
        public LabelSettings? LabelSettings { get; set; }
        public BoardListSettings? BoardListSettings { get; set; }
        public BoardActionSettings? BoardActionSettings { get; set; }

        //Prefixes
        public string? LabelColumnHeaderPrefix { get; set; }
        public string? ListColumnHeaderPrefix { get; set; }
        public string? CustomFieldPrefix { get; set; }
        public string? CheckItemPrefix { get; set; }
    }

    public class BoardSettings
    {
        public List<string>? IncludedFields { get; set; }
        public bool IncludeLabels { get; set; }
        public bool IncludeLists { get; set; }
    }

    public class CardSettings
    {
        public List<string>? IncludedFields { get; set; }
        public bool IncludeLabels { get; set; }
        public bool IncludeCheckItems { get; set; }

    }

    public class LabelSettings
    {
        public List<string>? IncludedFields { get; set; }
    }

    public class BoardListSettings
    {
        public List<string>? IncludedFields { get; set; }
    }


    public class BoardActionSettings
    {
        public List<string>? IncludedFields { get; set; }
        public List<string>? IncludedDataFields { get; set; }
    }
}