namespace TrelloDownloadManager
{
    public class CsvFileManager(string rootPath)
    {

        public void CreateFile(string foldername, List<string> names, List<List<string>> values)
        {
            var headerline = string.Join(';', names);
            var valueLines = values.Select(x => string.Join(';', x.Select(y => y.Replace("\n", "").Replace(";", "").Replace("\"", "")))).ToList();
            var lines = new List<string> { headerline };
            lines.AddRange(valueLines);

            var filename = Path.Combine(rootPath, foldername);
            File.Delete(filename);
            File.AppendAllLines(filename, lines);
        }
    }
}