using System.Text.Json;

namespace TrelloDownloadManager.Domain
{
    public class Board : NamedElement
    {
        public List<CustomField> CustomFields { get; }
        public List<Label> Labels { get; }
        public List<BoardList> BoardLists { get; }
        public List<CheckList> CheckLists { get; }
        public List<BoardAction> BoardActions { get; }
        public List<Card> Cards { get; }
        public CustomField? DonorfyCustomField { get; }

        public List<string> FixedValues { get; }
        public Configuration Configuration { get; }

        public Board(JsonElement element, Configuration configuration) : base(element)
        {
            Configuration = configuration;
            CustomFields = element.GetList("customFields", x => new CustomField(x));
            DonorfyCustomField = CustomFields.SingleOrDefault(x => x.Name == "ID");
            Labels = element.GetList("labels", x => new Label(x, configuration, Name));
            BoardLists = element.GetList("lists", x => new BoardList(x, configuration, Name)); ;
            CheckLists = element.GetList("checklists", x => new CheckList(x));
            BoardActions = element.GetList("actions", x => new BoardAction(x, configuration));

            var checkListsByCardId = CheckLists.ToLookup(x => x.IdCardString);
            var boardListNames = BoardLists.ToDictionary(x => x.Id, x => x.Name);
            var customFieldNamesById = CustomFields.ToDictionary(x => x.Id, x => x.Name);
            Cards = element.GetList("cards", x => new Card(x, configuration, Name, boardListNames, checkListsByCardId, customFieldNamesById));

            var includedFieldValues = configuration.BoardSettings?.IncludedFields ?? [];
            FixedValues = [.. includedFieldValues.Select(x => element.GetWithDefaultFromType(x))];
        }

        public List<string> GetValues(NameLists nameLists)
        {
            var customFieldValues = nameLists.GetCustomFieldMatchList(CustomFields);
            var labelValues = Configuration.BoardSettings?.IncludeLabels ?? false ? nameLists.GetLabelMatchList(Labels) : [];
            var boardlistValues = Configuration.BoardSettings?.IncludeLists ?? false ? nameLists.GetBoardListMatchList(BoardLists) : [];
            return [.. FixedValues, .. customFieldValues, .. labelValues, .. boardlistValues];
        }
    }
}