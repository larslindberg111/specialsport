using System.Text.Json;

namespace TrelloDownloadManager.Domain
{
    public class BoardAction
    {
        public List<string> FixedValues { get; }
        public List<string> DataValues { get; }
        public List<string> DataPropertyNames { get; }

        public BoardAction(JsonElement element, Configuration configuration)
        {
            var includedFields = configuration?.BoardActionSettings?.IncludedFields ?? [];
            FixedValues = [.. includedFields.Select(x => element.GetWithDefaultFromType(x))];
            var includedDataFieldValues = configuration?.BoardActionSettings?.IncludedDataFields ?? [];
            DataValues = [.. includedDataFieldValues.Select(x => element.GetWithDefaultFromType(x))];
            var dataElement = element.GetProperty("data");
            DataPropertyNames = dataElement.GetPropertyNames("data");
        }

        public List<string> GetValues()
        {
            return [.. FixedValues, .. DataValues];
        }
    }
}