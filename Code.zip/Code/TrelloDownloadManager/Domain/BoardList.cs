using System.Text.Json;

namespace TrelloDownloadManager.Domain
{
    public class BoardList : NamedElement
    {
        public List<string> FixedValues { get; }
        public string BoardName { get; }
        public Configuration Configuration { get; }

        public BoardList(JsonElement element, Configuration configuration, string boardName) : base(element)
        {
            BoardName = boardName;
            var includedFieldValues = configuration.BoardListSettings?.IncludedFields ?? [];
            FixedValues = [.. includedFieldValues.Select(x => element.GetWithDefaultFromType(x))];
            Configuration = configuration;
        }

        public List<string> GetValues()
        {
            var namedValues = new List<string> { BoardName };
            return [.. namedValues, .. FixedValues];
        }
    }
}