using System.Text.Json;

namespace TrelloDownloadManager.Domain
{
    public class Card : NamedElement
    {
        public string BoardName { get; }
        public string BoardListName { get; }
        public int DonorfyId { get; }
        public List<string> FixedValues { get; }
        public Configuration Configuration { get; }

        public List<CustomFieldItem> CustomFieldItems { get; }
        public List<Label> Labels { get; }
        public List<CheckItem> CheckItems { get; }

        public Card(JsonElement element, Configuration configuration, string boardName,
          Dictionary<string, string> boardListNameByBoardListId, ILookup<string, CheckList> checkListsByCardId, Dictionary<string, string> customFieldNamesById
          ) : base(element)
        {
            Configuration = configuration;
            var includedFieldValues = configuration.CardSettings?.IncludedFields ?? [];
            FixedValues = [.. includedFieldValues.Select(x => element.GetWithDefaultFromType(x))];

            BoardName = boardName;
            var idList = element.GetWithDefaultFromType("idList");
            BoardListName = boardListNameByBoardListId.TryGetValue(idList, out string? value) ? value : "";

            CustomFieldItems = element.GetList("customFieldItems", x => new CustomFieldItem(x, customFieldNamesById));
            DonorfyId = GetDonorfyId() ?? 0;

            Labels = element.GetList("labels", x => new Label(x, Configuration, boardName));
            CheckItems = [.. checkListsByCardId[Id].SelectMany(x => x.CheckItems)];
        }

        private int? GetDonorfyId()
        {
            var idCustomFieldItem = CustomFieldItems.FirstOrDefault(x => x.Name == "ID");
            if (idCustomFieldItem != null)
            {
                if (int.TryParse(idCustomFieldItem.Value, out var id))
                {
                    return id;
                }
            }
            return null;
        }

        public List<string> GetValues(NameLists nameLists)
        {
            var namedValues = new List<string> { BoardName, BoardListName };
            var checkItemValues = Configuration.CardSettings?.IncludeCheckItems ?? false ? nameLists.GetCheckItemStateList(CheckItems) : [];
            var labelValues = Configuration.CardSettings?.IncludeLabels ?? false ? nameLists.GetLabelMatchList(Labels) : [];
            return [.. namedValues, .. FixedValues, .. checkItemValues, .. labelValues];
        }
    }
}