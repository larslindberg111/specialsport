using System.Text.Json;

namespace TrelloDownloadManager.Domain
{
    public class CheckItem(JsonElement element) : NamedElement(element)
    {
        public string State { get; } = element.GetWithDefaultFromType("state");
    }
}