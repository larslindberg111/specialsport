using System.Text.Json;

namespace TrelloDownloadManager.Domain
{
    public class CheckList(JsonElement element) : NamedElement(element)
    {
        public List<CheckItem> CheckItems { get; } = element.GetList("checkItems", x => new CheckItem(x));
        public string IdCardString { get; } = element.GetWithDefaultFromType("idCard");
    }
}