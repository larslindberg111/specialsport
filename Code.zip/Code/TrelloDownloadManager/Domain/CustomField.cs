using System.Text.Json;

namespace TrelloDownloadManager.Domain
{
    public class CustomField(JsonElement element) : NamedElement(element)
    {
    }
}