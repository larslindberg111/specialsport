using System.Text.Json;

namespace TrelloDownloadManager.Domain
{
    public class CustomFieldItem
    {
        public string Name { get; }
        public string Id { get; }
        public string Value { get; }
        public string IdCustomField { get; }

        public CustomFieldItem(JsonElement element, Dictionary<string, string> customFieldNamesById)
        {
            IdCustomField = element.GetWithDefaultFromType("idCustomField");
            Name = customFieldNamesById.TryGetValue(IdCustomField, out string? value) ? value : "";
            Id = element.GetWithDefaultFromType("id");
            Value = "";
            if (element.TryGetProperty("value", out var v))
            {
                if (v.TryGetProperty("number", out var v2))
                {
                    Value = v2.GetString() ?? "";
                }
            }
        }
    }
}