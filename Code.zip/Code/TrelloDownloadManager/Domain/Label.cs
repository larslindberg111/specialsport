using System.Text.Json;

namespace TrelloDownloadManager.Domain
{
    public class Label : NamedElement
    {
        public string BoardName { get; }
        public List<string> FixedValues { get; }

        public Label(JsonElement element, Configuration configuration, string boardName) : base(element)
        {
            BoardName = boardName;
            var includedFields = configuration.LabelSettings?.IncludedFields ?? [];
            FixedValues = [.. includedFields.Select(x => element.GetWithDefaultFromType(x))];
        }

        public List<string> GetValues()
        {
            var namedValues = new List<string> { BoardName };
            return [.. namedValues, .. FixedValues];
        }
    }
}