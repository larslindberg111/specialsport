namespace TrelloDownloadManager.Domain
{
    public class NameLists(List<Board> boards, Configuration configuration)
    {
        public List<string> CustomFieldNames { get; } = boards.SelectMany(x => x.CustomFields).Select(x => x.Name).Distinct().OrderBy(x => x).ToList();
        public List<string> CustomFieldHeaders => CustomFieldNames.Select(x => $"{Configuration.CustomFieldPrefix ?? ""}{x}").ToList();
        public List<string> LabelNames { get; } = boards.SelectMany(x => x.Labels).Select(x => x.Name).Distinct().OrderBy(x => x).ToList();
        public List<string> LabelHeaders => LabelNames.Select(x => $"{Configuration.LabelColumnHeaderPrefix ?? ""}{x}").ToList();
        public List<string> BoardListNames { get; } = boards.SelectMany(x => x.BoardLists).Select(x => x.Name).Distinct().OrderBy(x => x).ToList();
        public List<string> BoardListHeaders => BoardListNames.Select(x => $"{Configuration.ListColumnHeaderPrefix ?? ""}{x}").ToList();
        public List<string> CheckItemNames { get; } = boards.SelectMany(x => x.CheckLists).SelectMany(x => x.CheckItems).Select(x => x.Name).Distinct().OrderBy(x => x).ToList();
        public List<string> CheckItemHeaders => CheckItemNames.Select(x => $"{Configuration.CheckItemPrefix ?? ""}{x}").ToList();
        public Configuration Configuration { get; } = configuration;

        public List<string> GetCustomFieldMatchList(List<CustomField> customFields)
        {
            var result = CustomFieldNames.Select(x => customFields.FirstOrDefault(y => y.Name == x)?.Id ?? "").ToList();
            return result;
        }

        public List<string> GetLabelMatchList(List<Label> labels)
        {
            var result = LabelNames.Select(x => labels.FirstOrDefault(y => y.Name == x)?.Id ?? "").ToList();
            return result;
        }

        public List<string> GetBoardListMatchList(List<BoardList> boardLists)
        {
            var result = BoardListNames.Select(x => boardLists.FirstOrDefault(y => y.Name == x)?.Id ?? "").ToList();
            return result;
        }

        public List<string> GetCheckItemStateList(List<CheckItem> checkItems)
        {
            var result = CheckItemNames.Select(x => checkItems.FirstOrDefault(y => y.Name == x)?.State ?? "").ToList();
            return result;
        }


        public List<string> GetBoardHeader()
        {
            var includedHeaders = Configuration.BoardSettings?.IncludedFields ?? [];
            var labelHeaders = Configuration.BoardSettings?.IncludeLabels ?? false ? LabelHeaders : [];
            var listHeaders = Configuration.BoardSettings?.IncludeLists ?? false ? BoardListHeaders : [];
            return [.. includedHeaders, .. CustomFieldHeaders, .. labelHeaders, .. listHeaders];
        }

        public List<string> GetBoardActionHeader()
        {
            var includedHeaders = Configuration.BoardActionSettings?.IncludedFields ?? [];
            var includedDataFields = Configuration.BoardActionSettings?.IncludedDataFields ?? [];
            return [.. includedHeaders, .. includedDataFields];
        }

        public List<string> GetBoardListHeader()
        {
            var namedHeaders = new List<string> { "boardName" };
            var includedHeaders = Configuration.BoardListSettings?.IncludedFields ?? [];
            return [.. namedHeaders, .. includedHeaders];
        }

        public List<string> GetLabelHeader()
        {
            var namedHeaders = new List<string> { "boardName" };
            var includedHeaders = Configuration.LabelSettings?.IncludedFields ?? [];
            return [.. namedHeaders, .. includedHeaders];
        }

        public List<string> GetCardHeader()
        {
            var namedHeaders = new List<string> { "boardName", "boardListName" };
            var includedHeaders = Configuration?.CardSettings?.IncludedFields ?? [];
            var checkItemHeaders = Configuration?.CardSettings?.IncludeCheckItems ?? false ? CheckItemHeaders : [];
            var labelHeaders = Configuration?.CardSettings?.IncludeLabels ?? false ? LabelHeaders : [];
            return [.. namedHeaders, .. includedHeaders, .. checkItemHeaders, .. labelHeaders];
        }
    }
}