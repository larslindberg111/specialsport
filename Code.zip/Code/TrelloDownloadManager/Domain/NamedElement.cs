using System.Text.Json;

namespace TrelloDownloadManager.Domain
{
    public class NamedElement(JsonElement element)
    {
        public string Name { get; } = element.GetWithDefaultFromType("name");
        public string Id { get; } = element.GetWithDefaultFromType("id");
    }
}