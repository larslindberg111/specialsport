using System.Text.Json;

namespace TrelloDownloadManager
{
    public static class Extensions
    {
        public static string GetWithDefaultFromType(this JsonElement element, string propertyName)
        {
            var property = GetPropertyOrNull(element, propertyName);
            if (!property.HasValue)
            {
                return "";
            }
            var p = property.Value;
            switch (p.ValueKind)
            {
                case JsonValueKind.String:
                    return p.GetString() ?? "";
                case JsonValueKind.Number:
                    if (p.TryGetInt32(out int intValue))
                    {
                        return intValue.ToString();
                    }
                    if (p.TryGetDecimal(out decimal decimalValue))
                    {
                        return decimalValue.ToString();
                    }
                    return "Unknown";
                case JsonValueKind.True:
                    return "Yes";
                case JsonValueKind.False:
                    return "No";
                default:
                    return p.GetRawText();
            }
        }

        private static JsonElement? GetPropertyOrNull(this JsonElement jsonElement, string propertyName)
        {
            var parts = propertyName.Split("_");
            var currentElement = jsonElement;
            foreach (var part in parts)
            {
                if (currentElement.ValueKind == JsonValueKind.Null)
                {
                    return null;
                }
                if (currentElement.TryGetProperty(part, out JsonElement propertyElement))
                {
                    currentElement = propertyElement;
                }
                else
                {
                    return null;
                }
            }
            return currentElement;
        }

        public static List<T> GetList<T>(this JsonElement element, string propertyName, Func<JsonElement, T> func)
        {
            if (element.TryGetProperty(propertyName, out JsonElement propertyElement))
            {
                if (propertyElement.ValueKind == JsonValueKind.Array)
                {
                    return propertyElement.EnumerateArray().Select(func).ToList();
                }
                else
                {
                    Console.WriteLine($"Property '{propertyName}' is not an Array type, and cannot be used in lists.");
                    return [];
                }
            }
            else
            {
                Console.WriteLine($"Property '{propertyName}' could not be found.");
                return [];
            }
        }

        public static List<string> GetPropertyNames(this JsonElement element, string path)
        {
            var result = new List<string>() { };
            var propertyNames = element.EnumerateObject().Select(x => x.Name).ToList();
            foreach (var propertyName in propertyNames)
            {
                var p = element.GetProperty(propertyName);
                var combinedPath = string.Join('_', [path, propertyName]);
                if (p.ValueKind == JsonValueKind.Object)
                {
                    result.AddRange(GetPropertyNames(p, combinedPath));
                }
                else
                {
                    if (p.ValueKind != JsonValueKind.Null)
                    {
                        result.Add(combinedPath);
                    }
                    else
                    {
                        result.Add("TODO");
                    }
                }
            }
            return result;
        }
    }
}