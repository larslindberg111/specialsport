﻿using TrelloDownloadManager;

var configuration = TrelloManager.GetConfiguration();
if (configuration != null)
{
  TrelloManager.GenerateFiles(configuration);
}

Console.WriteLine("Finished");
Console.ReadLine();
