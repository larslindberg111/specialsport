using System.Text.Json;
using TrelloDownloadManager.Domain;

namespace TrelloDownloadManager
{
  public static class TrelloManager
  {
    public static string configFileName = "config.json";

    public static Configuration? GetConfiguration()
    {
      var exepath = AppDomain.CurrentDomain.BaseDirectory;
      var configFullPath = $"{exepath}\\{configFileName}";
      if (!File.Exists(configFullPath))
      {
        Console.WriteLine($"ERROR: Missing configuration file. Could not find configuration file named: {configFileName}. A configuration file is requred for the application to run");
        return null;
      }
      Console.WriteLine($"INFO: Started reading configuration file: {configFileName}");
      var configFile = File.ReadAllText(configFullPath);
      if (configFile is null)
      {
        Console.WriteLine("ERROR: Could not read configuration file.");
        return null;
      }
      Configuration? configuration = JsonSerializer.Deserialize<Configuration>(configFile);
      if (configuration is null)
      {
        Console.WriteLine("ERROR: The specified configuration file is not a valid. It must have a valid configuration file format");
        return null;
      }
      if (!IsValid(configuration))
      {
        return null;
      }
      Console.WriteLine("Configuration file has been read succesfully.");
      return configuration;
    }

    private static bool IsValid(Configuration configuration)
    {
      if (configuration.InputFolder is null)
      {
        Console.WriteLine("ERROR: InputFolder not specified in configuration file");
        return false;
      }
      if (!Directory.Exists(configuration.InputFolder))
      {
        Console.WriteLine($"ERROR: Input folder {configuration.InputFolder} does not exist. Make sure the specified input folder is the existing folder containing the json files.");
        return false;
      }
      if (!Directory.Exists(configuration.OutputFolder))
      {
        Console.WriteLine($"ERROR: Output folder {configuration.OutputFolder} does not exist. Make sure the specified output folder is an existing folder.");
        return false;
      }
      return true;
    }

    public static void GenerateFiles(Configuration configuration)
    {
      var boards = GetBoards(configuration);
      var nameLists = new NameLists(boards, configuration);

      if (configuration.OutputFolder is null)
      {
        Console.WriteLine("ERROR: Output folder is not specified");
        return;
      }

      var csvFileManager = new CsvFileManager(configuration.OutputFolder);

      var boardLines = boards
        .Select(x => x.GetValues(nameLists))
        .ToList();
      csvFileManager.CreateFile("boards.csv", nameLists.GetBoardHeader(), boardLines);

      var labelLines = boards
        .SelectMany(x => x.Labels)
        .Select(x => x.GetValues())
        .ToList();
      csvFileManager.CreateFile("labels.csv", nameLists.GetLabelHeader(), labelLines);

      var boardListLines = boards
        .SelectMany(x => x.BoardLists)
        .Select(x => x.GetValues())
        .ToList();
      csvFileManager.CreateFile("boardlists.csv", nameLists.GetBoardListHeader(), boardListLines);

      var cardLines = boards
        .SelectMany(x => x.Cards)
        .Select(x => x.GetValues(nameLists))
        .ToList();
      csvFileManager.CreateFile("cards.csv", nameLists.GetCardHeader(), cardLines);

      var boardActionLines = boards
        .SelectMany(x => x.BoardActions)
        .Select(x => x.GetValues())
        .ToList();
      csvFileManager.CreateFile("boardactions.csv", nameLists.GetBoardActionHeader(), boardActionLines);

      var boardActionDataFields = boards
        .SelectMany(x => x.BoardActions)
        .SelectMany(x => x.DataPropertyNames)
        .Distinct()
        .OrderBy(x => x)
        .Select(x => $"\"{x}\"")
        .ToList();
    }

    private static List<Board> GetBoards(Configuration configuration)
    {
      if (configuration.InputFolder is null)
      {
        Console.WriteLine("ERROR: Input folder is not specified.");
        return [];        
      }
      var result = new List<Board>();
      var files = Directory.GetFiles(configuration.InputFolder);
      foreach (var filename in files)
      {
        if (!filename.EndsWith(".json"))
        {
          Console.WriteLine($"Skipping file : {filename}. Only files with extension JSON are included.");
          continue;
        }

        string jsonText = File.ReadAllText(filename);
        Console.WriteLine($"Reading file {filename}");
        using JsonDocument doc = JsonDocument.Parse(jsonText);
        var b = new Board(doc.RootElement, configuration);
        result.Add(b);
      }
      return result;
    }
  }
}