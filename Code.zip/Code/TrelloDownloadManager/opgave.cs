
// Opgave:
// Lav en fil der indeholder en liste med alle kort hvorom der gælder
// Niveau 1 er region
// Niveau 2 er kommune
// Niveau 3 er skole

// Regionen findes ud fra navnet på boardet
// Kommunen findes ud fra kommunekortet. Der skal være et kommunekort i hver liste. Et kommunekort kan kendes på at det har en checkliste der indeholder "Resultat: Skolemodning"
// Skoler findes ud fra de kort i listen der har label "PraktikIndsats opstartet"

// Eksempel på region er "Region Midtjylland"
// Eksempel på kommune er "Arhus kommune"
// Eksempel på skole er "Trekløver skolen"




// De skal være på workspace: 2.0 Sportspraktik Koordinering
// De skal være på et af de 5 boards for regioner
// De skal grupperes ud fra hvilke board de er på (Regionsnavn)
// Der skal kun medtages de kort der har label "Sportspraktik 2.0 kommune"
// Der skal kun medtages kort som har "PraktikIndsats opstartet" label

// Listen skal bla indeholde:
// - Arhus og Herning kommune (Midtjylland)
// - Listen skal blandt andet indeholde Trekløver skolen og vårvangskolen






// Listen skal grupperes efter region og dernæst efter kommune


// For hvert kort skal skrives kortets overskrift


// Eks på fil

// Region Midtjylland
//   Aarhus Kommune ()
//     Rundhøjskolen ()
//     Stengård skolen
// ...


// Fremgangsmåde:
// Listen kan genereres af et program som køres på brugerens computer
// Programmet skal have en fil der indeholder Export fra Trello
// Programmet produceret en ny fil
// Brugeren skal kopiere filen til der hvor den læses af websitet

